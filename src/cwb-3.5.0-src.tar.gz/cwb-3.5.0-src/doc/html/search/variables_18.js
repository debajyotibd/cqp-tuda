var searchData=
[
  ['x_5fsize_4572',['x_size',['../struct___b_a_rdesc.html#a623043d49db5cdb1e40ecd92c0d911ee',1,'_BARdesc']]],
  ['xmax_4573',['XMax',['../regex2dfa_8c.html#a80bffaf26394cc5144152dbfa4c03219',1,'regex2dfa.c']]],
  ['xml_5faware_4574',['xml_aware',['../cwb-check-input_8c.html#a4df8011de8bc0b2e7750c2acc1d87cd7',1,'xml_aware():&#160;cwb-check-input.c'],['../cwb-encode_8c.html#a4df8011de8bc0b2e7750c2acc1d87cd7',1,'xml_aware():&#160;cwb-encode.c']]],
  ['xml_5fcompatible_4575',['xml_compatible',['../cwb-decode_8c.html#a9b893f3996c4fc03d4b94fed6a02b62b',1,'cwb-decode.c']]],
  ['xs_4576',['Xs',['../regex2dfa_8c.html#ad16b38e7643b781aea9d0d5ab790092d',1,'regex2dfa.c']]],
  ['xstack_4577',['XStack',['../regex2dfa_8c.html#a3ec799bc6b92e0401d3078ddb17d651d',1,'regex2dfa.c']]]
];
