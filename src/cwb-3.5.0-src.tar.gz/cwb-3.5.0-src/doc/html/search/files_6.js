var searchData=
[
  ['globals_2ec_2780',['globals.c',['../globals_8c.html',1,'']]],
  ['globals_2eh_2781',['globals.h',['../globals_8h.html',1,'']]],
  ['groups_2ec_2782',['groups.c',['../groups_8c.html',1,'']]],
  ['groups_2eh_2783',['groups.h',['../groups_8h.html',1,'']]]
];
