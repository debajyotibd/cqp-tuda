var searchData=
[
  ['greek_4791',['greek',['../cl_8h.html#aa018eeb7e5a4bb1586a3f4337011daeaa1e664ae89ee112a145ec85d1e895ae50',1,'cl.h']]]
];
