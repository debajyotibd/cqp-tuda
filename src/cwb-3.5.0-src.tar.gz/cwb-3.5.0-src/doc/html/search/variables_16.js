var searchData=
[
  ['val_4543',['val',['../unionc__tree.html#aa0ccb5ee6d882ee3605ff47745c6467b',1,'c_tree']]],
  ['valid_4544',['valid',['../struct__variable__buf.html#ac63b1f168765a53e565a8ba27f5469d1',1,'_variable_buf']]],
  ['value_4545',['Value',['../structequation.html#afaa224cd6416f18b1f97a0a48ca02e73',1,'equation']]],
  ['value_4546',['value',['../struct___d_c_r.html#a2c6f5abe3b3de913d87dd5ff0569a82b',1,'_DCR::value()'],['../struct_t_corpus_property.html#a4e9aec275e566b978a3ccb4e043d8c61',1,'TCorpusProperty::value()']]],
  ['variables_5fiterator_5fidx_4547',['variables_iterator_idx',['../variables_8c.html#ac8e9a240d9cbb3af0182115e28953c01',1,'variables.c']]],
  ['variablespace_4548',['VariableSpace',['../variables_8c.html#a19937d091f54317988e5c696472fe430',1,'VariableSpace():&#160;variables.c'],['../variables_8h.html#a19937d091f54317988e5c696472fe430',1,'VariableSpace():&#160;variables.c']]],
  ['varname_4549',['varName',['../unionc__tree.html#ae2fd30fa390eaa244ab9253866d6fb97',1,'c_tree']]],
  ['varref_4550',['varref',['../unionc__tree.html#aa7df177653306b386905cc78d5804d8c',1,'c_tree']]],
  ['vector_5fsize_4551',['vector_size',['../struct___b_a_rdesc.html#a21138f2658d1883e163c8322b9074a06',1,'_BARdesc']]],
  ['verbose_4552',['verbose',['../cwb-align-encode_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;cwb-align-encode.c'],['../cwb-align_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;cwb-align.c'],['../cwb-check-input_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;cwb-check-input.c'],['../cwb-encode_8c.html#a0b2caeb4b6f130be43e5a2f0267dd453',1,'verbose():&#160;cwb-encode.c']]],
  ['verbose_5fparser_4553',['verbose_parser',['../options_8h.html#ab5b74ed35a1a6e3a4b16fb6f67202e00',1,'verbose_parser():&#160;options.c'],['../options_8c.html#ab5b74ed35a1a6e3a4b16fb6f67202e00',1,'verbose_parser():&#160;options.c']]],
  ['virtual_5fid_4554',['virtual_id',['../struct___hash.html#a0576607974f4c06f8031128c0754b9ca',1,'_Hash']]],
  ['vstack_4555',['vstack',['../structfeature__maps__t.html#ac7b1f647cad8ea029b9548de24f47079',1,'feature_maps_t']]]
];
