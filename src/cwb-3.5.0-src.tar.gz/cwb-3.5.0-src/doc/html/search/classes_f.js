var searchData=
[
  ['userentry_2716',['UserEntry',['../struct_user_entry.html',1,'']]]
];
