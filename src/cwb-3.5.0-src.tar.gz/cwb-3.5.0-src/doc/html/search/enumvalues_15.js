var searchData=
[
  ['xmlmode_4906',['XMLMode',['../cwb-decode_8c.html#a0af77925a490c13d34e06331f645138ead0b96059ec780d9d0d26d8c6ea9d8cb4',1,'cwb-decode.c']]]
];
