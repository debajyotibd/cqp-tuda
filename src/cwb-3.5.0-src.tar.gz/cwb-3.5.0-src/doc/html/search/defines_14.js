var searchData=
[
  ['wide_5fcol_5fsep_5286',['WIDE_COL_SEP',['../cwb-align-show_8c.html#af70c5d48a1b292e7adc48487f6e10d27',1,'cwb-align-show.c']]],
  ['wide_5fcol_5fwidth_5287',['WIDE_COL_WIDTH',['../cwb-align-show_8c.html#a0a4b39ca90cac0a2506e1243769540a7',1,'cwb-align-show.c']]]
];
