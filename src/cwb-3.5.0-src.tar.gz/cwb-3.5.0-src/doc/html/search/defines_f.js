var searchData=
[
  ['readpositionstream_5239',['ReadPositionStream',['../cl_8h.html#aa21e6ecf20b6066920a124ae612a2e5b',1,'cl.h']]],
  ['rep_5fcheck_5flexhash_5fsize_5240',['REP_CHECK_LEXHASH_SIZE',['../cwb-encode_8c.html#a6a288a8d723a941718269f64a5367ea8',1,'cwb-encode.c']]],
  ['repeat_5finf_5241',['repeat_inf',['../eval_8h.html#a29161a23b1e886c8322cd5deeefef553',1,'eval.h']]],
  ['repeat_5fnone_5242',['repeat_none',['../eval_8h.html#ae9969d2d44807103e8aa9b169498aabc',1,'eval.h']]],
  ['require_5fnfc_5243',['REQUIRE_NFC',['../cl_8h.html#aa0c07ad5df716ec7aba3dba491c5ab8d',1,'cl.h']]],
  ['rng_5favs_5244',['RNG_AVS',['../cwb-s-encode_8c.html#ac564cf16dc29432e8cea29d765029015',1,'cwb-s-encode.c']]],
  ['rng_5favx_5245',['RNG_AVX',['../cwb-s-encode_8c.html#a6c5f9b401ab4105fad64ebfb799ba3db',1,'cwb-s-encode.c']]],
  ['rng_5frng_5246',['RNG_RNG',['../cwb-s-encode_8c.html#a38b5fae8084025c0eec1cbe31c2b196b',1,'cwb-s-encode.c']]]
];
