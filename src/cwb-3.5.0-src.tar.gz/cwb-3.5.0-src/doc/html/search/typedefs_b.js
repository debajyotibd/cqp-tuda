var searchData=
[
  ['opttype_4664',['OptType',['../options_8h.html#a1a06ca7344225e684c17645971d7a034',1,'options.h']]],
  ['outputmode_4665',['OutputMode',['../cwb-decode_8c.html#a7a036f86735cc7d0190e038c78ea3e59',1,'cwb-decode.c']]]
];
