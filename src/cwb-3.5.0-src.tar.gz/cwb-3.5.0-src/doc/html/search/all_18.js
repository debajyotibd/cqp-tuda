var searchData=
[
  ['x_5fextend_2612',['X_EXTEND',['../regex2dfa_8c.html#a937010b1ea193413d38657aae3963394',1,'regex2dfa.c']]],
  ['x_5fsize_2613',['x_size',['../struct___b_a_rdesc.html#a623043d49db5cdb1e40ecd92c0d911ee',1,'_BARdesc']]],
  ['xmax_2614',['XMax',['../regex2dfa_8c.html#a80bffaf26394cc5144152dbfa4c03219',1,'regex2dfa.c']]],
  ['xml_5faware_2615',['xml_aware',['../cwb-check-input_8c.html#a4df8011de8bc0b2e7750c2acc1d87cd7',1,'xml_aware():&#160;cwb-check-input.c'],['../cwb-encode_8c.html#a4df8011de8bc0b2e7750c2acc1d87cd7',1,'xml_aware():&#160;cwb-encode.c']]],
  ['xml_5fcompatible_2616',['xml_compatible',['../cwb-decode_8c.html#a9b893f3996c4fc03d4b94fed6a02b62b',1,'cwb-decode.c']]],
  ['xmlmode_2617',['XMLMode',['../cwb-decode_8c.html#a0af77925a490c13d34e06331f645138ead0b96059ec780d9d0d26d8c6ea9d8cb4',1,'cwb-decode.c']]],
  ['xs_2618',['Xs',['../regex2dfa_8c.html#ad16b38e7643b781aea9d0d5ab790092d',1,'regex2dfa.c']]],
  ['xstack_2619',['XStack',['../regex2dfa_8c.html#a3ec799bc6b92e0401d3078ddb17d651d',1,'regex2dfa.c']]]
];
