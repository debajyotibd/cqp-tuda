var searchData=
[
  ['query_5fbuffer_5fsize_5238',['QUERY_BUFFER_SIZE',['../cqp_8h.html#a3d65e5ebeda0733ad22f5f9ea26d76f4',1,'cqp.h']]]
];
