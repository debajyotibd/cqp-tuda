var searchData=
[
  ['umask_5282',['UMASK',['../cwb-encode_8c.html#abc83d313581e501ef608cf2bd7db2816',1,'UMASK():&#160;cwb-encode.c'],['../cwb-s-encode_8c.html#abc83d313581e501ef608cf2bd7db2816',1,'UMASK():&#160;cwb-s-encode.c']]],
  ['unselected_5flines_5283',['UNSELECTED_LINES',['../ranges_8h.html#a45d4eee525446d5a26f6a62936b3ad0f',1,'ranges.h']]],
  ['use_5fsort_5fcache_5284',['USE_SORT_CACHE',['../ranges_8c.html#aa2fd7f53e809588a035630d6fb2f0009',1,'ranges.c']]]
];
