var searchData=
[
  ['which_5fapp_5ft_4689',['which_app_t',['../options_8h.html#a9cb1e8b8e5118b1bcf1f13ad491d7a7f',1,'options.h']]]
];
