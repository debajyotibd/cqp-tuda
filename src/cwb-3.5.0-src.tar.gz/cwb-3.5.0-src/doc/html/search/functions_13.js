var searchData=
[
  ['unget_3719',['UNGET',['../regex2dfa_8c.html#a8903a293346bb080e1e8445051d3aa6d',1,'regex2dfa.c']]],
  ['update_5fcontext_5fdescriptor_3720',['update_context_descriptor',['../context__descriptor_8c.html#a14d9faf7f37cbb4a51b5d0f4f543c8ea',1,'update_context_descriptor(Corpus *corpus, ContextDescriptor *cd):&#160;context_descriptor.c'],['../context__descriptor_8h.html#a14d9faf7f37cbb4a51b5d0f4f543c8ea',1,'update_context_descriptor(Corpus *corpus, ContextDescriptor *cd):&#160;context_descriptor.c']]],
  ['update_5fgrain_5fbuffer_3721',['update_grain_buffer',['../regopt_8c.html#a519a8017ebde2cd7ac31f0b7558a1544',1,'regopt.c']]]
];
