var searchData=
[
  ['bool_4928',['bool',['../cwb-globals_8h.html#abb452686968e48b67397da5f97445f5b',1,'cwb-globals.h']]],
  ['bufsize_4929',['BUFSIZE',['../makecomps_8c.html#aeca034f67218340ecb2261a22c2f3dcd',1,'makecomps.c']]]
];
