var searchData=
[
  ['grant_4644',['Grant',['../auth_8c.html#a78d9f6320063646948cfa6b02fa3195b',1,'auth.c']]],
  ['group_4645',['Group',['../groups_8h.html#a2d58a1f122db5c1634c24364283a2ec2',1,'groups.h']]]
];
