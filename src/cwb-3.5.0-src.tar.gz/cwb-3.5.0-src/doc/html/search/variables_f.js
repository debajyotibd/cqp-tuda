var searchData=
[
  ['offset_4242',['offset',['../structs__att__builder.html#aed7ea92f45bd273dde380a45ddced592',1,'s_att_builder::offset()'],['../structmini__s__builder.html#aed7ea92f45bd273dde380a45ddced592',1,'mini_s_builder::offset()'],['../struct___hash.html#a8aa7374967f204dfae0b46fd98e301f9',1,'_Hash::offset()'],['../struct_t_mblob.html#ad5f0842c40c7e46344fd8df70187fa0f',1,'TMblob::offset()']]],
  ['offset1_4243',['offset1',['../struct___tabulation_item.html#aee7f28409ab837ab7ab64c0cb1a2dafb',1,'_TabulationItem::offset1()'],['../struct__sort__clause.html#aee7f28409ab837ab7ab64c0cb1a2dafb',1,'_sort_clause::offset1()']]],
  ['offset2_4244',['offset2',['../struct___tabulation_item.html#aed6fb01d8bf85735a69307c7795f89bd',1,'_TabulationItem::offset2()'],['../struct__sort__clause.html#aed6fb01d8bf85735a69307c7795f89bd',1,'_sort_clause::offset2()']]],
  ['old_5fquery_5fcorpus_4245',['old_query_corpus',['../parse__actions_8h.html#a112ca11ea3543de38241fb947b923a7a',1,'old_query_corpus():&#160;parse_actions.c'],['../parse__actions_8c.html#a112ca11ea3543de38241fb947b923a7a',1,'old_query_corpus():&#160;parse_actions.c']]],
  ['op_5fid_4246',['op_id',['../unionc__tree.html#aa8f9cd944c56f5101c43853b6dd23735',1,'c_tree::op_id()'],['../unione__tree.html#ad5c9c2759fdbf570ce1c9c67f960ec04',1,'e_tree::op_id()'],['../unione__tree.html#a0d7f3895d2d4b00a64bfe9f6df80d5ca',1,'e_tree::op_id()']]],
  ['opcode_4247',['opcode',['../union__avs.html#a3c38b3f797a8f99209ab2bdb62ca3a44',1,'_avs']]],
  ['open_5fstreams_4248',['open_streams',['../fileutils_8c.html#af3845d5ed0fdc9729f6c2b7a72f918a0',1,'fileutils.c']]],
  ['opt_5fabbrev_4249',['opt_abbrev',['../struct__cqpoption.html#ac2bcb379c9612b1e0a522c485889fc06',1,'_cqpoption']]],
  ['opt_5fname_4250',['opt_name',['../struct__cqpoption.html#ad370f616d731d0e001b8a66f1294fba8',1,'_cqpoption']]],
  ['outfile_5fname_4251',['outfile_name',['../cwb-align_8c.html#a398dbfce693e05e8a530ed6c34180c1c',1,'cwb-align.c']]],
  ['output_5fbinary_5franges_4252',['output_binary_ranges',['../options_8c.html#a99376aad27cfc39079c58d65e99d770c',1,'output_binary_ranges():&#160;options.c'],['../options_8h.html#a99376aad27cfc39079c58d65e99d770c',1,'output_binary_ranges():&#160;options.c']]],
  ['output_5ffd_4253',['output_fd',['../cwb-check-input_8c.html#aa51dcc579ff331baa79ae48dcd661c1b',1,'cwb-check-input.c']]],
  ['output_5ffile_4254',['output_file',['../cwb-check-input_8c.html#a4d59733effad59b54bbd4e5d6016c538',1,'output_file():&#160;cwb-check-input.c'],['../cwb-scan-corpus_8c.html#a4d59733effad59b54bbd4e5d6016c538',1,'output_file():&#160;cwb-scan-corpus.c']]]
];
