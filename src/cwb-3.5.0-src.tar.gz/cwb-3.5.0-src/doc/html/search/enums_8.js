var searchData=
[
  ['re_5fops_4712',['re_ops',['../eval_8h.html#ac9229123fa1af8bdfab732ba95159cb4',1,'eval.h']]],
  ['rng_5fsetops_4713',['rng_setops',['../ranges_8h.html#aeb5ec9cdebf03b5a87f9c2e19012cf4d',1,'ranges.h']]]
];
