var searchData=
[
  ['avs_5fregion_5fop_4699',['avs_region_op',['../eval_8h.html#a456229b8a7c8ae65bd1f6403d4a9b5e7',1,'eval.h']]]
];
