var searchData=
[
  ['case_5fmode_4702',['case_mode',['../corpmanag_8h.html#a2499845cf1a7faad4b8a53bd342d27c0',1,'corpmanag.h']]],
  ['component_5fstates_4703',['component_states',['../attributes_8h.html#ac10aa9d039808185e4c1756539499c1c',1,'attributes.h']]],
  ['cooc_5fop_4704',['cooc_op',['../eval_8h.html#a7d4b5eb690301089c99bd87353a3e724',1,'eval.h']]],
  ['corpus_5ftype_4705',['corpus_type',['../corpmanag_8h.html#ab595f682e895370f86580c128681d88e',1,'corpmanag.h']]],
  ['ctxtdir_4706',['ctxtdir',['../eval_8h.html#a057366ca550f608ccc7310ec896f0719',1,'eval.h']]]
];
