var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz",
  1: "_abcdefghimprstuv",
  2: "abcdefghlmnoprstuvw",
  3: "_abcdefghilmnopqrstuvwy",
  4: "_abcdefghijklmnopqrstuvwxy",
  5: "abcdefghilmoprstuvw",
  6: "_abcelmprstw",
  7: "abcefghiklmnopqrstuvwxz",
  8: "abcdefghilmnopqrstuvwx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

