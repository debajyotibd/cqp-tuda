var searchData=
[
  ['temp_5ffilename_5fbufsize_5277',['TEMP_FILENAME_BUFSIZE',['../cwb-globals_8h.html#a4ab6f745e550d4d87a22024b6a8e0897',1,'cwb-globals.h']]],
  ['tempdir_5fpath_5278',['TEMPDIR_PATH',['../cwb-globals_8h.html#a49b0f5b674c01903678ddc980caf93fa',1,'cwb-globals.h']]],
  ['top_5279',['TOP',['../regex2dfa_8c.html#afc0eef637f1016e8786e45e106a4881e',1,'regex2dfa.c']]],
  ['true_5280',['True',['../cqp_8h.html#add3ca9eefe3b5b754426f51d3043e579',1,'cqp.h']]],
  ['true_5281',['true',['../cwb-globals_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7',1,'cwb-globals.h']]]
];
